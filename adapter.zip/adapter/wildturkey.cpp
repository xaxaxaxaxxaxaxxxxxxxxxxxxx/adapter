#include "wildturkey.h"

WildTurkey::WildTurkey()
{

}

void WildTurkey::gobble() {
    cout << "Gobble gobble" << endl;
}

void WildTurkey::fly() {
    cout << "I`m flying a short distance" << endl;

}
