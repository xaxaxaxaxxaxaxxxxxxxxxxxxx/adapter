#include "turkey.h"

Turkey::Turkey(){

}
