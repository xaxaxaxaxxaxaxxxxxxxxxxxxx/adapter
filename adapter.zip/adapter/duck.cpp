#include "duck.h"

Duck::Duck(){

}
