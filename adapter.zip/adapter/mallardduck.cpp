#include "mallardduck.h"

MallardDuck::MallardDuck()
{

}

void MallardDuck::quack() {
    cout << "Quack" << endl;
}

void MallardDuck::fly() {
    cout << "I`m flying" << endl;

}
