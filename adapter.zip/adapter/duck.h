#ifndef DUCK_H
#define DUCK_H

class Duck
{
	public:
		Duck();
    	virtual void quack() = 0;
    	virtual void fly() = 0;
};

#endif
